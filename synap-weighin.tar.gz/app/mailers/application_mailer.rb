class ApplicationMailer < ActionMailer::Base
  default from: "kev@kevinmchugh.me"
end